const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({viewport:{width:390,height:1000}});
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto('file:///home/claude/trabajo/index.html');
  await p.waitForTimeout(2500);
  let ok=0,mal=0;
  const T=(n,c,d)=>{ if(c){ok++;console.log('  ✅ '+n);} else {mal++;console.log('  ❌ '+n+(d?'  →  '+d:''));} };

  console.log('\n1️⃣  🔑 TODO RECUADRO DE LA APP ESTÁ EN LA LISTA DEL BOTÓN ATRÁS');
  const r1 = await p.evaluate(()=>{
    // Todos los ids de recuadro que la app crea o tiene en el HTML
    const enLista = RECUADROS_ENCIMA.map(x=>x.id);
    // Los que se crean al vuelo: se buscan en el código
    const codigo = document.documentElement.innerHTML;
    const creados = new Set();
    const re = /\.id\s*=\s*['"]([a-z0-9-]*(?:overlay|-ov|-box|editor-pago-compra)[a-z0-9-]*)['"]/gi;
    let m;
    while((m = re.exec(codigo))) creados.add(m[1]);
    // Y los que viven en el HTML
    document.querySelectorAll('[id*="overlay"],[id$="-ov"]').forEach(e=>creados.add(e.id));
    // Estos dos NO deben estar: el menú lateral se cierra en el peldaño 0, y el letrero
    // de salir es justamente el que pregunta si salir de la app.
    const aProposito = ['menu-lateral-overlay','salir-ov'];
    const faltan = [...creados].filter(id=>!enLista.includes(id) && !aProposito.includes(id));
    return { enLista: enLista.length, encontrados: creados.size, faltan };
  });
  console.log('     en la lista: ' + r1.enLista + '   ·   recuadros hallados: ' + r1.encontrados);
  T('🔑 NINGÚN recuadro se quedó fuera de la lista', r1.faltan.length===0, JSON.stringify(r1.faltan));

  console.log('\n2️⃣  LOS CUATRO NUEVOS ESTÁN');
  const r2 = await p.evaluate(()=>{
    const ids = RECUADROS_ENCIMA.map(x=>x.id);
    const necesarios = ['estado-cuenta-overlay','avisar-cliente-overlay','editor-pago-compra','cierre-ruta-overlay'];
    return { faltan: necesarios.filter(x=>!ids.includes(x)),
             cierres: RECUADROS_ENCIMA.filter(x=>necesarios.includes(x.id)).map(x=>({id:x.id, fn:x.cerrar})) };
  });
  T('los 4 están en la lista', r2.faltan.length===0, JSON.stringify(r2.faltan));
  T('y cada uno con su función de cerrar', r2.cierres.every(x=>!!x.fn), JSON.stringify(r2.cierres));

  console.log('\n3️⃣  Y ESAS FUNCIONES EXISTEN');
  const r3 = await p.evaluate(()=>{
    const fns = ['cerrarEstadoDeCuenta','cerrarAvisoCliente','cerrarEditorPagoCompra','cerrarCierreRuta'];
    return fns.filter(f=>typeof window[f] !== 'function');
  });
  T('🔒 las 4 funciones de cerrar existen', r3.length===0, JSON.stringify(r3));

  console.log('\n4️⃣  🔑 EL BOTÓN ATRÁS CIERRA EL ESTADO DE CUENTA, NO LA APP');
  const r4 = await p.evaluate(async ()=>{
    ['pantalla-login','pantalla-bloqueo'].forEach(id=>{const e=document.getElementById(id); if(e) e.style.display='none';});
    const a=document.getElementById('app-contenido'); if(a) a.style.display='block';
    localStorage.setItem('ncl', JSON.stringify([{id:26,nombre:'Carlos',apellido:'Tavarez',negocio:'LUXURY',tel:'4015168653'}]));
    localStorage.setItem('nv','[]');
    clientes=LS('ncl',[]); ventas=LS('nv',[]);
    verCl(26);
    await new Promise(r=>setTimeout(r,400));
    abrirEstadoDeCuenta(26);
    await new Promise(r=>setTimeout(r,300));
    const abiertoAntes = document.getElementById('estado-cuenta-overlay').style.display !== 'none';
    // Un paso atrás, como el botón del teléfono
    const seMovio = unPasoAtras();
    await new Promise(r=>setTimeout(r,200));
    const abiertoDespues = document.getElementById('estado-cuenta-overlay').style.display !== 'none';
    return { abiertoAntes, seMovio, abiertoDespues, sigueEnLaFicha: pantallaActual()==='p-cl-perfil' };
  });
  T('el estado de cuenta estaba abierto', r4.abiertoAntes);
  T('🔑 el botón atrás lo cierra', r4.abiertoDespues===false, String(r4.abiertoDespues));
  T('🔑 y dice que SÍ se movió (no cierra la app)', r4.seMovio===true, String(r4.seMovio));
  T('🔒 y te deja en la ficha del cliente', r4.sigueEnLaFicha, 'pantalla');

  console.log('\n5️⃣  🔑 LO MISMO CON EL AVISO DEL COMPROBANTE');
  const r5 = await p.evaluate(async ()=>{
    ofrecerMensajeAlCliente(26, 'pago', 100, null);
    await new Promise(r=>setTimeout(r,250));
    const antes = document.getElementById('avisar-cliente-overlay').style.display !== 'none';
    const seMovio = unPasoAtras();
    await new Promise(r=>setTimeout(r,150));
    const despues = document.getElementById('avisar-cliente-overlay').style.display !== 'none';
    return { antes, seMovio, despues };
  });
  T('el aviso estaba abierto', r5.antes);
  T('🔑 el botón atrás lo cierra', r5.despues===false, String(r5.despues));
  T('y no cierra la app', r5.seMovio===true);

  console.log('\n6️⃣  🔑 Y CON EL CIERRE DE RUTA');
  const r6 = await p.evaluate(async ()=>{
    localStorage.setItem('np', JSON.stringify([{id:'p1',nombre:'Gel',marca:'G',costo:4,precio:10,stock:20,min:5}]));
    localStorage.setItem('nvan', JSON.stringify({fechaCarga:'2026-08-20', cargado:{p1:10}}));
    loadProds();
    abrirCierreRuta();
    await new Promise(r=>setTimeout(r,250));
    const antes = document.getElementById('cierre-ruta-overlay').style.display !== 'none';
    const seMovio = unPasoAtras();
    await new Promise(r=>setTimeout(r,150));
    const despues = document.getElementById('cierre-ruta-overlay').style.display !== 'none';
    return { antes, seMovio, despues };
  });
  T('el cierre de ruta estaba abierto', r6.antes);
  T('🔑 el botón atrás lo cierra', r6.despues===false, String(r6.despues));

  console.log('\n7️⃣  📤 EL MENSAJE LARGO SE MANDA DIRECTO');
  const r7 = await p.evaluate(()=>{
    localStorage.setItem('nv', JSON.stringify([
      {id:301,cid:26,cn:'Carlos',tipo:'credito',fecha:'07/01/2026',total:262,ganancia:60,
       items:[{nombre:'Gel',cant:1,precio:262,costo:202}],
       pagosFactura:[{pid:'x',recibo:'R1',montoCobro:120,monto:120,fecha:'07/10/2026'}]}]));
    ventas=LS('nv',[]);
    SS('nbs_wa_pegar','0');
    const largo = textoEstadoDeCuenta(26);
    const enlace = _linkWhatsApp('4015168653', largo);
    return { chars: enlace.length, pasaElLimite: enlace.length > 6000 };
  });
  console.log('     el enlace del largo mide ' + r7.chars + ' caracteres');
  T('🔑 el largo NO pasa el límite: se manda directo', !r7.pasaElLimite, String(r7.chars));

  console.log('\n8️⃣  🔒 SOLO SE COPIA SI ÉL LO ESCOGE, O SI ES ENORME');
  const r8 = await p.evaluate(async ()=>{
    let copiado=null;
    const oc=navigator.clipboard;
    Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:(t)=>{copiado=t; return Promise.resolve();}}});
    const oa=window.alert; window.alert=()=>{};
    // 1) modo normal, mensaje normal → NO copia
    SS('nbs_wa_pegar','0');
    try { enviarPorWhatsAppACliente(26, 'Hola Sr. Carlos\n\nPagaste $120.00.'); } catch(e){}
    const normalCopio = !!copiado;
    // 2) él escoge copiar y pegar → SÍ copia
    copiado=null; SS('nbs_wa_pegar','1');
    try { enviarPorWhatsAppACliente(26, 'Hola Sr. Carlos\n\nPagaste $120.00.'); } catch(e){}
    const escogidoCopio = !!copiado;
    SS('nbs_wa_pegar','0');
    window.alert=oa;
    Object.defineProperty(navigator,'clipboard',{configurable:true,value:oc});
    return { normalCopio, escogidoCopio };
  });
  // 🛡️ Desde el 3 sep copia SIEMPRE antes de abrir, por si el enlace falla. Es a propósito.
  T('🛡️ copia el mensaje antes de abrir, siempre', r8.normalCopio===true, String(r8.normalCopio));
  T('🔒 y si él escoge copiar y pegar, sí copia', r8.escogidoCopio===true, String(r8.escogidoCopio));


  // ⚠️ Los bloques de arriba dejaron el navegador navegando. Se recarga la página para
  // que el contexto quede limpio antes de mirar el mecanismo del letrero.
  await p.goto('file:///home/claude/trabajo/index.html');
  await p.waitForTimeout(2200);

  console.log('\n9️⃣  🔑 CON EL LETRERO DE SALIR ABIERTO, ATRÁS NO HACE NADA');
  // ⚠️ Aquí NO se puede disparar el popstate de verdad: en un archivo local el navegador
  // no tiene historial que gastar y se sale de la página. Se comprueba el MECANISMO:
  // que el código haga lo que tiene que hacer.
  const r9 = await p.evaluate(()=>{
    const codigoMostrar = String(mostrarLetreroSalir);
    // El manejador del botón atrás está en el listener; se busca en el archivo.
    const codigoApp = document.documentElement.innerHTML;
    return {
      yaNoDeshace: codigoMostrar.indexOf('history.go(-pasos)') < 0,
      diceQueSeQueda: /Atras no hace nada/.test(codigoMostrar),
      absorbeElAtras: /letrero abierto: atras ignorado/.test(codigoApp),
      reponeGuardian: /_cajaSalir[\s\S]{0,200}pushState/.test(codigoApp)
    };
  });
  T('🔑 ya NO deshace los guardianes al abrir el letrero', r9.yaNoDeshace);
  T('🔑 con el letrero abierto, el atrás se ignora', r9.absorbeElAtras);
  T('🔑 y repone el guardián que se comió', r9.reponeGuardian);

  console.log('\n🔟  ✋ SOLO SE SALE TOCANDO UN BOTÓN');
  const r10 = await p.evaluate(async ()=>{
    mostrarLetreroSalir();
    await new Promise(r=>setTimeout(r,150));
    const box = document.getElementById('salir-box');
    const abierto = box.style.display === 'block';
    const btns = [...box.querySelectorAll('button')].map(x=>({ t:x.textContent.trim().slice(0,30), oc:x.getAttribute('onclick')||'' }));
    cerrarLetreroSalir();
    await new Promise(r=>setTimeout(r,150));
    return { abierto, btns, cerroAlQuedarse: box.style.display !== 'block', guardianes: profundidadGuardian() };
  });
  console.log('     botones: ' + JSON.stringify(r10.btns.map(x=>x.t)));
  T('el letrero se abre', r10.abierto);
  T('hay dos botones', r10.btns.length >= 2, String(r10.btns.length));
  T('✋ uno para quedarse y otro para salir',
     r10.btns.some(x=>/cerrarLetreroSalir/.test(x.oc)) && r10.btns.some(x=>/salirDeLaApp/.test(x.oc)),
     JSON.stringify(r10.btns.map(x=>x.oc)));
  T('✋ "quedarme" cierra el letrero', r10.cerroAlQuedarse);
  T('🔒 y repone la protección completa', r10.guardianes >= 6, String(r10.guardianes));

  console.log('\n1️⃣1️⃣  🛡️ EL COLCHÓN SE RELLENA AL CAMBIAR DE PANTALLA');
  const r11 = await p.evaluate(async ()=>{
    const codigoIr = String(ir);
    return { loHace: /ponerGuardianAtras/.test(codigoIr), minimo: MIN_GUARDIANES };
  });
  T('🛡️ cambiar de pantalla rellena el colchón', r11.loHace);
  T('y el mínimo subió de 6 a 20', r11.minimo===20, String(r11.minimo));

  console.log('\n1️⃣2️⃣  🚪 EL BOTÓN DE SALIR SÍ INTENTA CERRAR');
  const r12 = await p.evaluate(()=>{
    const codigo = String(salirDeLaApp);
    return {
      quitaGuardianes: /history\.go\(-\(pasos/.test(codigo),
      yaNoSoloAvisa: codigo.indexOf('mostrando aviso de tocar atras') < 0,
      tieneRespaldo: /no se pudo cerrar solo/.test(codigo)
    };
  });
  T('🚪 quita los guardianes y retrocede', r12.quitaGuardianes);
  T('🚪 ya no se limita a pedirte que toques atrás', r12.yaNoSoloAvisa);
  T('🔒 y si el teléfono no deja, te avisa', r12.tieneRespaldo);

  console.log('\n1️⃣3️⃣  🔑 EL LETRERO NO DESARMA LA PROTECCIÓN (medido, no leído)');
  const r13b = await p.evaluate(async ()=>{
    // 🔴 La mutación se escapaba porque solo se miraba el TEXTO del código.
    // Ahora se MIDE: con el letrero abierto tienen que quedar guardianes.
    ir('p-inicio');
    await new Promise(r=>setTimeout(r,150));
    _ultimoGuardian = 0; ponerGuardianAtras();
    const antes = profundidadGuardian();
    mostrarLetreroSalir();
    await new Promise(r=>setTimeout(r,350));   // por si intentara deshacerlos
    const despues = profundidadGuardian();
    cerrarLetreroSalir();
    return { antes, despues };
  });
  console.log('     guardianes: ' + r13b.antes + ' antes → ' + r13b.despues + ' con el letrero abierto');
  T('🔑 la protección SIGUE ahí con el letrero abierto', r13b.despues > 0, String(r13b.despues));
  T('🔑 y no se deshizo ninguna', r13b.despues >= r13b.antes, r13b.antes + ' → ' + r13b.despues);

  console.log(`\n  ${ok} bien · ${mal} mal`);
  const reales=errs.filter(e=>!/firebase|onAuthStateChanged/i.test(e));
  if(reales.length){ console.log('⚠️ JS:'); reales.forEach(e=>console.log('   '+e)); }
  await b.close();
  process.exit(mal||reales.length?1:0);
})();
