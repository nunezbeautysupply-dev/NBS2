#!/bin/bash
# 🛡️ LA REVISIÓN COMPLETA — se corre ANTES DE CADA ENTREGA, sin excepción.
# Sensei, 30 ago: "no sé qué es lo que vas a hacer para que no sigan pasando estas cosas".
# Esto es lo que se va a hacer.
cd /home/claude
FALLOS=0

echo "════════════════════════════════════════"
echo "  🛡️  REVISIÓN COMPLETA DE NBS 2"
echo "════════════════════════════════════════"
echo
echo "── 1. EL HTML ESTÁ SANO ──"
python3 guardian_html.py trabajo/index.html || FALLOS=1
echo
echo "── 2. NO SE ROMPIÓ NADA DESDE EL RESPALDO ──"
# ⚠️ Se compara contra el ultimo respaldo SANO. Uno roto daria falsa alarma
# para siempre, y una alarma que siempre suena deja de servir.
ULTIMO=""
for R in $(ls -t RESPALDO_*.html 2>/dev/null); do
  if python3 guardian_html.py "$R" >/dev/null 2>&1; then ULTIMO="$R"; break; fi
done
if [ -n "$ULTIMO" ]; then
  python3 guardian_html.py "$ULTIMO" trabajo/index.html || FALLOS=1
else
  echo "  (sin respaldo con el que comparar)"
fi
echo
echo "── 3. EL JAVASCRIPT ──"
cd trabajo && python3 /home/claude/extraer_js.py >/dev/null && node --check app.js && echo "  ✅ sintaxis correcta" || { echo "  🔴 SINTAXIS ROTA"; FALLOS=1; }
cd /home/claude
echo
echo "── 4. LA ESTRUCTURA DE LA APP ──"
node auditoria_total.js 2>&1 | grep -E "bien ·|❌" || FALLOS=1
echo
echo "── 5. EL DINERO ──"
node auditoria_dinero.js 2>&1 | grep -E "bien ·|❌"
echo
echo "── 5b. CONTABILIDAD PARALELA ──"
node contabilidad_paralela.js 2>&1 | grep -E "DAN LO MISMO|DIFERENCIA" || FALLOS=1
echo
echo "── 5c. FUZZING DEL DINERO ──"
node fuzzing_dinero.js 2>&1 | grep -E "aguantaron|ROMPEN" || FALLOS=1
echo
echo "── 6. LAS SUITES ──"
MAL=0
for t in probar_vip probar_fechas probar_mandar_balance probar_confirmar_balance probar_boton_atras probar_whatsapp probar_estado_cuenta \
         probar_menu_grande probar_inicio_y_uso probar_perfil_suplidor probar_cxc \
         probar_vigilante probar_cierre_ruta probar_devolucion_motivo probar_busqueda_todas \
         probar_busqueda_frase probar_compactar probar_acordeon probar_barbero_activo \
         probar_firmas_aparte probar_subida_nube probar_coma_dinero probar_editar_pago_suplidor \
         probar_editar_cliente probar_version_inicio probar_proveedor_pref probar_opciones_catalogo \
         probar_precio_cero probar_saldo_facturas probar_marcar_visita probar_aviso_nube \
         probar_pago_suplidor probar_costo probar_descuentos probar_dinero_compras probar_editor_compra; do
  R=$(node $t.js 2>&1 | grep 'bien ·')
  if echo "$R" | grep -qv '· 0 mal'; then echo "  🔴 $t → $R"; MAL=1; FALLOS=1; fi
done
[ $MAL -eq 0 ] && echo "  ✅ las 33 suites en verde"
echo
echo "── 6b. MUTACIÓN: ¿las pruebas protegen de verdad? ──"
cd laboratorio && cp /home/claude/trabajo/index.html BASE.html
timeout 1800 python3 mutacion.py 2>&1 | grep -E "cazadas  ·|SE ESCAPÓ" || FALLOS=1
cd /home/claude
echo
echo "── 6c. COBERTURA: ¿cuánto de la app se toca? ──"
cd laboratorio && timeout 400 node cobertura_real.js 2>&1 | grep -E "cobertura|tocadas al"
cd /home/claude
echo
echo "── 7. DIFERENCIAL Y BOTONES ──"
node diferencial.js 2>&1 | tail -1
node barrido_botones.js 2>&1 | grep -E "ninguna revent|🔴"
echo
echo "════════════════════════════════════════"
if [ $FALLOS -eq 0 ]; then
  echo "  ✅ TODO EN VERDE — se puede entregar"
else
  echo "  🔴 HAY FALLOS — NO ENTREGAR"
fi
echo "════════════════════════════════════════"
exit $FALLOS
